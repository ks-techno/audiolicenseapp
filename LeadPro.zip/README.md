## Starter Project Using Laravel Vue Ant

This is starter project for basic setup using laravel, vue and Ant. Following below steps for the setup

-   Create Modules Folder if not exists.
-   composer install
-   npm install
-   npm run watch
