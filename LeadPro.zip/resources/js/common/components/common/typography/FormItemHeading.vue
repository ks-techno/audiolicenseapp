<template>
    <a-typography-title :level="5">
        <slot></slot>
    </a-typography-title>
    <a-divider
        style="
            height: 2px;
            background-color: #f0f2f5;
            margin-top: 5px;
            margin-bottom: 20px;
        "
    />
</template>

<script>
export default {};
</script>

<style></style>
